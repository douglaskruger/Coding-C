extern int executeGet(void);
extern int executeDrop(void);
extern int executeAsk(void);
extern int executeGive(void);
extern int executeInventory(void);
