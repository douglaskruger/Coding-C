extern OBJECT *reachableObject(const char *intention, const char *noun);
