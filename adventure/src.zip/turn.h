extern bool turn(int time);
