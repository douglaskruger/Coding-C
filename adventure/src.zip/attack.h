extern int executeAttack(void);
